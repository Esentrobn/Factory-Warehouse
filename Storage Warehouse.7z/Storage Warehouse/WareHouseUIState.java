
public abstract class WareHouseUIState{
	protected static WarehouseUIContext context;
    public WareHouseUIState(){

    }
    public abstract void run();
}